from fastapi import FastAPI

app = FastAPI()

@app.get("/")
def func(address: str):
    if len(address) >= 100:
        return true "آدرس درست است"
    else:
        return false "آدرس نباید بیشتر از 100 حرف باشد"