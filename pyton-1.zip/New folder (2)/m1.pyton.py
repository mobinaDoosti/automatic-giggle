from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

@app.get("/test/{number}")
def read(number):
    number = str(number)
    if len(number) != 11:
        return false"ارقام وارد شده نادرست است"
    if int(number[0:3]) < 400 or int(number[0:3]) > 402:
        return false".قسمت سال نادرست است"
    if int(number[3:9]) != 114150:
        return false".قسمت ثابت نادرست است"
    if int(number[9]) == 0:
        if int(number[10]) == 0:
            return false".قسمت اندیس نادرست است"
    else:
        return true".شماره دانشجویی وارد شده درست است"


@app.get("/")
def func(number):
    number = str(number)
    if len(number) != 11:
        return false"شماره دانشجویی باید 11 رقم باشد. تعداد ارقام وارد شده نادرست است"
    if int(number[0:3]) < 400 or int(number[0:3]) > 402:
        return false".قسمت سال نادرست است"
    if int(number[3:9]) != 114150:
        return false".قسمت ثابت نادرست است"
    if int(number[9]) == 0:
        if int(number[10]) == 0:
            return false".قسمت اندیس نادرست است"
    else:
        return true".شماره دانشجویی وارد شده درست است"


class number(BaseModel):
    number: int


@app.post("/ok/")
def req(nb: number):
    nb = str(nb)
    if len(nb) != 26:
        return false"شماره دانشجویی باید 11 رقم باشد. تعداد ارقام وارد شده نادرست است"
    if int(nb[0:3]) < 400 or int(nb[0:3]) > 402:
        return false".قسمت سال نادرست است"
    if int(nb[3:9]) != 114150:
        return false".قسمت ثابت نادرست است    if int(nb[9]) == 0:
        if int(nb[10]) == 0:
            return false".قسمت اندیس نادرست است"
    else:
        return true".شماره دانشجویی وارد شده درست است"