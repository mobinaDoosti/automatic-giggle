from fastapi import FastAPI

app = FastAPI()


@app.get("/")
def func(postalcode: str):
    s = 0
    for i in postalcode:
        s += 1
    if s == 10 and (48 <= ord(i) <= 57):
        return true"کد پستی درست است"
    else:
        return false "کد پستی نادرست است"
