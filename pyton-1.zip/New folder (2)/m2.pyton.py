from fastapi import FastAPI

app = FastAPI()

@app.get("/")
def the_name(name: str):
    s = 0
    if s > 10:
        return false"نام نباید از ده کاراکتر بیشتر شود"

    for i in name:
        s += 1
        if not ord(i) == 32 and 0 <= ord(i) <= 127:
            return false"فقط حروف الفبای فارسی و بدون کاراکتر های خاص قابل قبول است"
    else:
        return true"فرمت نام وارد شده درست است"
