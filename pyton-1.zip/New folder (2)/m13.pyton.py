from fastapi import FastAPI

app = FastAPI()

@app.get("/")
def func(check: str):
    if check == "مجرد":
        return check
    if check == "متاهل":
        return check
    else:
        return"وضعیت تاهل را به درستی وارد کنید"
