from fastapi import FastAPI

app = FastAPI()


@app.get("/")
def func(number: str):
    if len(number) != 11:
        return false"شماره تلفن وارد شده باید دقیقا 11 رقم باشد"

    if not all(48 <= ord(char) <= 57 for char in number[2:]):
        return false"شماره تلفن فقط  شامل اعداد باشد"

    if number[0] != '0' or number[1] != '9':
        return false"شماره تلفن باید با 09 شروع شود"

    return true"شماره تلفن همراه وارد شده معتبر است"
